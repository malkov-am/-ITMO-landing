# ITMO-landing
Лендинг для лаборатории ИТМО.

Состав команды:
- [klimetzc](https://github.com/klimetzc)
- [AlexandrMachilov](https://github.com/AlexandrMachilov)
- [gWildCat](https://github.com/gWildCat)
- [krasotun](https://github.com/krasotun)
- [Sergynya174](https://github.com/Sergynya174)
- [volkovakv](https://github.com/volkovakv)
